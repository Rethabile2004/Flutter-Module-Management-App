package com.example.firebase_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
